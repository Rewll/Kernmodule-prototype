public interface ITriggerable
{
    void OnTrigger();
}
